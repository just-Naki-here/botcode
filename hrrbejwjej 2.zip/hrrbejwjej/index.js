const TOKEN = 'MTM2OTIyMzM4NjUxNzIwOTE3OA.GQEIBj.KHu5O0KGMr-0qagWDyQFk3UsFSC2TkcMXP5iSU';
const { Client, GatewayIntentBits, Partials, Events } = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel]
});

const puzzles = JSON.parse(fs.readFileSync('./data/puzzles.json'));
const memory = JSON.parse(fs.readFileSync('./data/memory.json'));

client.once(Events.ClientReady, () => {
    console.log(`The Weaver is online as ${client.user.tag}`);
});

client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith('!nexus')) return;

    const args = message.content.slice(7).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'trigger') {
        const puzzleId = args[0];
        const puzzle = puzzles.find(p => p.id === puzzleId);
        if (!puzzle) {
            return message.channel.send('Puzzle not found.');
        }

        const channel = message.guild.channels.cache.find(c => c.name === puzzle.channel);
        if (!channel) return message.channel.send('Target channel not found.');

        channel.send(puzzle.text);
        if (puzzle.file) {
            const filePath = path.join(__dirname, 'data/assets', puzzle.file);
            if (fs.existsSync(filePath)) {
                channel.send({ files: [filePath] });
            }
        }

        if (puzzle.unlocks) {
            for (const chanName of puzzle.unlocks) {
                const chan = message.guild.channels.cache.find(c => c.name === chanName);
                if (chan) {
                    chan.permissionOverwrites.edit(message.guild.roles.everyone, { ViewChannel: true });
                }
            }
        }

        message.channel.send('Puzzle triggered.');
    }
});

client.login(TOKEN);