// Glitch text effect for cryptic messaging

function applyGlitchEffect(text) {
    return text
        .split('')
        .map(c => (Math.random() > 0.8 ? String.fromCharCode(33 + Math.random() * 94) : c))
        .join('');
}

module.exports = { applyGlitchEffect };