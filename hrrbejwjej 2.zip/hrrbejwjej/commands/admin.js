const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'admin',
    description: 'Admin command set for managing puzzles and memory data.',
    execute(message, args) {
        if (!message.member.permissions.has('Administrator')) {
            return message.reply('You do not have permission to use this command.');
        }

        const subcommand = args[0];
        switch (subcommand) {
            case 'list-puzzles':
                const puzzles = JSON.parse(fs.readFileSync('./data/puzzles.json'));
                message.channel.send('Loaded Puzzles:\n' + puzzles.map(p => `- ${p.id}`).join('\n'));
                break;

            case 'add-memory':
                const userId = args[1];
                const memoryText = args.slice(2).join(' ');
                const memoryDataPath = './data/memory.json';
                const memoryData = JSON.parse(fs.readFileSync(memoryDataPath));

                if (!userId || !memoryText) {
                    return message.reply('Usage: !nexus admin add-memory <userId> <memory text>');
                }

                if (!memoryData[userId]) memoryData[userId] = [];
                memoryData[userId].push(memoryText);

                fs.writeFileSync(memoryDataPath, JSON.stringify(memoryData, null, 2));
                message.channel.send(`Memory added for user ${userId}.`);
                break;

            default:
                message.channel.send('Unknown admin subcommand.');
        }
    }
};